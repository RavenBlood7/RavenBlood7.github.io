package cards;

import cards.exceptions.EmptyDeckException;
import org.junit.Test;

import java.sql.SQLOutput;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

public class DeckOfCardsTest {

    @Test
    public void testInOrderDeck() {
        DeckOfCards deck = new DeckOfCards();
        //deck.shuffleDeck();
        Card singleCard;

        try {

            for (int i = 0; i < 52; i++) {
                singleCard = deck.drawCard();
                System.out.println(i + "\tDrew card: " + singleCard.toString());
            }
        } catch (EmptyDeckException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testDefaultShuffler() {
        DeckOfCards deck = new DeckOfCards();
        String beforeShuffle = deck.toString();
        deck.shuffleDeck();
        String afterShuffle = deck.toString();
        assertNotEquals(beforeShuffle, afterShuffle);

        Card singleCard;
        try {
            for (int i = 0; i < 52; i++) {
                singleCard = deck.drawCard();
                System.out.println(i + "\tDrew card: " + singleCard.toString());
            }
        } catch (EmptyDeckException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testSpecialShuffler() {
        DeckOfCards deck = new DeckOfCards();
        String beforeShuffle = deck.toString();
        deck.shuffleDeck(new DeckShuffler());
        String afterShuffle = deck.toString();

        assertNotEquals(beforeShuffle, afterShuffle);

        try {
            Card singleCard;
            for (int i = 0; i < 52; i++) {
                singleCard = deck.drawCard();
                System.out.println(i + "\tDrew card: " + singleCard.toString());
            }
        } catch (EmptyDeckException e) {
            e.printStackTrace();
        }
    }

    @Test(expected = EmptyDeckException.class)
    public void testDrawEmptyDeck() throws EmptyDeckException {
        DeckOfCards deck = new DeckOfCards();
        Card singleCard;

        // Draw All Cards
        for (int i = 0; i < 52; i++) {
            singleCard = deck.drawCard();
            System.out.println(i + "\tDrew card: " + singleCard.toString());
        }

        // Draw from empty deck
        singleCard = deck.drawCard();
        System.out.println("\n" + singleCard.toString());
    }
}