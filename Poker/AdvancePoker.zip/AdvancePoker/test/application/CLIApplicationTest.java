package application;


import org.junit.Test;

public class CLIApplicationTest {
    
    @Test
    public void testRequiredCLI(){
        String[] argList = new String[0];
        CLIApplication.main(argList);
    }

}