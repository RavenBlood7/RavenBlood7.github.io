package games;


import org.junit.Test;

public class CardGameTest {
    @Test
    public void gameSimulation1(){
        // Set Parameters
        Integer numPlayers = 1;
        Integer numCardsPerPlayer = 5;

        // Play Game
        CardGameController pokerGame = new CustomFiveCardDraw(numPlayers);
        pokerGame.dealCards(numCardsPerPlayer);
    }

    @Test
    public void testCardEvaluation(){
        // Set Parameters
        Integer numPlayers = 1;
        Integer numCardsPerPlayer = 5;

        // Play Game
        CardGameController pokerGame = new CustomFiveCardDraw(numPlayers);
        pokerGame.dealCards(numCardsPerPlayer);

        for (int i = 0; i < pokerGame.getNumPlayers(); i++) {
            System.out.println("player " + (i + 1) + " has: " + pokerGame.getPlayer(i).handToString());
            System.out.println("this is: " + pokerGame.evaluatePlayerHand(i));
        }
    }

    @Test
    public void testTenPlayers(){
        // Set Parameters
        Integer numPlayers = 10;
        Integer numCardsPerPlayer = 5;

        // Play Game
        CardGameController pokerGame = new CustomFiveCardDraw(numPlayers);
        pokerGame.dealCards(numCardsPerPlayer);

        for (int i = 0; i < pokerGame.getNumPlayers(); i++) {
            System.out.println("player " + (i + 1) + " has: " + pokerGame.getPlayer(i).handToString());
            System.out.println("this is: " + pokerGame.evaluatePlayerHand(i));
        }
    }

}