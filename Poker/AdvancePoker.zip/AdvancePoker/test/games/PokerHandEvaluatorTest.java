package games;

import cards.Card;
import cards.exceptions.InvalidCardSuitException;
import games.evaluators.HandEvaluator;
import games.evaluators.PokerHandEvaluator;
import org.junit.Test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import static org.junit.Assert.*;

public class PokerHandEvaluatorTest {

    @Test
    public void testEvaluateToString() {
        Player player = new Player();
        HandEvaluator eval = new PokerHandEvaluator();

        player.takeCard(new Card(Card.suit.CLUBS, 13));    // C13
        player.takeCard(new Card(Card.suit.CLUBS, 12));    // C12
        player.takeCard(new Card(Card.suit.CLUBS, 11));    // C11
        player.takeCard(new Card(Card.suit.CLUBS, 10));    // C10
        player.takeCard(new Card(Card.suit.CLUBS, 9));     // C9

        String evaluation = eval.evaluateToString(player.getHand());
        System.out.println("hand is: " + player.handToString());
        System.out.println("rank is: " + evaluation);
        assertEquals(evaluation, "Straight Flush");
    }

    @Test
    public void testCasesFromFile() {
        try {
            HandEvaluator eval = new PokerHandEvaluator();
            File file = new File("test/games/testCases.csv");
            FileReader fileReader = new FileReader(file);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String line;
            for (int i = 1; (line = bufferedReader.readLine()) != null; i++) {
                //if (i == 1) line = line.substring(1); // Remove Beginning of file character
                System.out.println("test " + i);
                Player player = new Player();
                String[] curTestCase = line.split(",");
                if (curTestCase[0].length() > 1) curTestCase[0] = curTestCase[0].substring(curTestCase[0].length() - 1);
                player.takeCard(new Card(curTestCase[0], curTestCase[1]));
                player.takeCard(new Card(curTestCase[2], curTestCase[3]));
                player.takeCard(new Card(curTestCase[4], curTestCase[5]));
                player.takeCard(new Card(curTestCase[6], curTestCase[7]));
                player.takeCard(new Card(curTestCase[8], curTestCase[9]));

                String evaluation = eval.evaluateToString(player.getHand());
                System.out.println("hand is: " + player.handToString());
                System.out.println("calculated rank is: " + evaluation);
                System.out.println("file rank is: " + curTestCase[10]);
                assertEquals(curTestCase[10], evaluation);
                System.out.println("------");
            }
            fileReader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }catch (InvalidCardSuitException e) {
            e.printStackTrace();
            e.printError();
        }


    }
}