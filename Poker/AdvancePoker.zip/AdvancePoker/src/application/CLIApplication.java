package application;

import games.CardGameController;
import games.CustomFiveCardDraw;

public class CLIApplication {

    public static void main(String args[]) {
        // Advance requirement
        if (args.length == 0) {
            try {
                // Set Parameters
                Integer numPlayers = 1;
                Integer numCardsPerPlayer = 5;

                // Play Game
                CardGameController customFiveCardDrawGame = new CustomFiveCardDraw(numPlayers);

                // Shuffle Deck
                customFiveCardDrawGame.shuffleDeck();
                for (int i = 0; i < 3; i++) {
                    System.out.print("Shuffling...");
                    System.out.flush();
                    Thread.sleep(1000);
                }


                customFiveCardDrawGame.dealCards(numCardsPerPlayer);
                System.out.println("\nYour Hand: " + customFiveCardDrawGame.getPlayer(0).handToString());
                System.out.println("You Have: " + customFiveCardDrawGame.evaluatePlayerHand(0));

            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
