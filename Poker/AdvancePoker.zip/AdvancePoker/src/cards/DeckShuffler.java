package cards;

import java.util.ArrayList;
import java.util.Collections;

/**
 * Ability to add one's own card-shuffling algorithm
 */
public class DeckShuffler {
    /**
     * @param deckOfCards the array of cards which is to be shuffled
     */
    public void shuffleDeck(ArrayList<Card> deckOfCards){

        // Implement "more realistic shuffling algorithm" here

        Collections.shuffle(deckOfCards);
    }
}
