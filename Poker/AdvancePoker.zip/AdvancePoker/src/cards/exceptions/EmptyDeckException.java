package cards.exceptions;

public class EmptyDeckException extends Throwable {
}
