package cards.exceptions;

public class InvalidCardSuitException extends Throwable {
    private String attemptedSuit;
    public InvalidCardSuitException(String s) {
        attemptedSuit = s;
    }

    public void printError()
    {
        System.out.println("The String which is invalid is: " + attemptedSuit);
    }
}
