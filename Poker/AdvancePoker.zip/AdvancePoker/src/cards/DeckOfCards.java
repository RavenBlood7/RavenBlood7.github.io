package cards;

import cards.exceptions.EmptyDeckException;

import java.util.ArrayList;
import java.util.Collections;

/**
 * A collection of cards which serves as a representation of a real deck within a game of cards
 */
public class DeckOfCards {
    private ArrayList<Card> deck = new ArrayList<Card>(52);


    /**
     * Constructor which makes a standard 52 card deck which is in order
     */
    public DeckOfCards()
    {
        // Create a Deck with 4 suits and 13 ranks per suit without Jokers
        for (Card.suit s: Card.suit.values()) {
            for (int i = 0; i < 13; i++) {
                Card newCard = new Card(s, i + 1);
                deck.add(newCard);
            }
        }

    }

    /**
     * Mix the cards of the deck according to the standard "Collections.shuffle" functionality
     */
    public void shuffleDeck()
    {
        Collections.shuffle(deck);
    }

    /**
     * Mix the cards of the deck according to a special programmer defined shuffling method
     * @param deckShuffler An object which has a programmer defined algorithm for shuffling a deck of cards
     */
    public void shuffleDeck(DeckShuffler deckShuffler)
    {
        deckShuffler.shuffleDeck(deck);
    }

    /**
     * Take a card from the deck of cards
     * @return The single card which was drawn
     * @throws EmptyDeckException Thrown if the deck of cards is empty
     */
    public Card drawCard() throws EmptyDeckException {
        if (!deck.isEmpty())
            return deck.remove(0);
        else
            throw new EmptyDeckException();
    }

    /**
     * @return a string of all the cards in the deck of the form: 1S 3H KS 10D ...
     */
    public String toString()
    {
        StringBuilder retString = new StringBuilder();
        for (int i = 0; i < deck.size(); i++) {
            retString.append(deck.get(i).toString()).append(" ");
        }
        return retString.toString();
    }
}
