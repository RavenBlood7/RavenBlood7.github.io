package cards;

import cards.exceptions.InvalidCardSuitException;

/**
 * A single "card" entity which mimics a French Playing Card.
 * Has four suits, namely Spades, Hearts, Clubs, and Diamonds
 */
public class Card {

    /**
     * The suit of this particular card: Spades, Hearts, Clubs, or Diamonds
     */
    private suit suit;

    /**
     * The number of the card. Notice 11 == Jack, 12 == Queen, 13 == King, and 1 == Ace
     */

    private Integer cardRank;

    /**
     * The possible suits which a card can be: Spades, Hearts, Clubs, or Diamonds
     */
    public enum suit {
        SPADES, HEARTS, CLUBS, DIAMONDS
    }

    /**
     * A Constructor which uses the card's "suit" enum to make the card
     * @param s The suit which the card object will have
     * @param cardRank The number on the card, or Ace, Jack, Queen, King as specified by cardRank variable
     */
    public Card(suit s, int cardRank) {
        this.suit = s;
        this.cardRank = cardRank;
    }

    /**
     * A Constructor which uses a Suit String ("S", "H", "C", "D") to make the card
     * @param s The suit which the card object will have
     * @param cardRank The number on the card, or Ace, Jack, Queen, King as specified by cardRank variable
     * @throws InvalidCardSuitException The card cannot be created because the string does not map to suit
     */
    public Card(String s, String cardRank) throws InvalidCardSuitException {
        switch (s) {
            case "S":
                this.suit = suit.SPADES;
                break;
            case "H":
                this.suit = suit.HEARTS;
                break;
            case "C":
                this.suit = suit.CLUBS;
                break;
            case "D":
                this.suit = suit.DIAMONDS;
                break;
            default:
                throw new InvalidCardSuitException(s);
        }
        this.cardRank = Integer.parseInt(cardRank);
    }

    /**
     * @return a string with the form: <rank><suit> (AS, 3H, JD, etc.)
     */
    public String toString() {
        return rankToString(cardRank) + suitToChar(suit);
    }

    /**
     * @param s The suit to map to a Character
     * @return a Character mapped to the provided suit (SPADES == 'S', HEARTS == 'H', CLUBS == 'C', DIAMONDS == 'D', Other == '?')
     */
    private Character suitToChar(suit s) {
        switch (s) {
            case SPADES:
                return 'S';
            case HEARTS:
                return 'H';
            case CLUBS:
                return 'C';
            case DIAMONDS:
                return 'D';
            default:
                return '?';
        }
    }

    /**
     * @return a string with the form: <rank><suit>, but the suit is the special terminal character for respective suit
     */
    public String toStringSpecial() {
        return rankToString(cardRank) + suitToCharSpecial(suit);
    }

    /**
     * @param suit The suit to map to a Character
     * @return a special Character mapped to the provided suit
     */
    private Character suitToCharSpecial(Card.suit suit) {
        switch (suit) {
        case SPADES:
            return '\u2660';
        case HEARTS:
            return '\u2764';
        case CLUBS:
            return '\u2663';
        case DIAMONDS:
            return '\u2666';
        default:
            return '?';
    }
    }

    /**
     * @param cardRank a number which is the card's rank
     * @return A string representing the rank/number provides (11 == "J", 12 == "Q", 13 == "K", 1 == "A")
     */
    private String rankToString(Integer cardRank) {
        switch (cardRank) {
            case 11:
                return "J";
            case 12:
                return "Q";
            case 13:
                return "K";
            case 1:
                return "A";
            default:
                return cardRank.toString();
        }
    }

    public Integer getNumber() {
        return cardRank;
    }

    public void setNumber(Integer cardRank) {
        this.cardRank = cardRank;
    }

    public Card.suit getSuit() {
        return suit;
    }

    public void setSuit(Card.suit suit) {
        this.suit = suit;
    }
}
