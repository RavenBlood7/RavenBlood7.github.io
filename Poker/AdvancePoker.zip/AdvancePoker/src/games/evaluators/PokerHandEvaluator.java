package games.evaluators;

import cards.Card;
import games.evaluators.exception.NotFiveCardHandException;

import java.util.ArrayList;
import java.util.Collections;

/**
 * Evaluation of 5-card hands specific for poker
 */
public class PokerHandEvaluator extends HandEvaluator {

    /**
     * An enum which represent all evaluations are possible in poker
     */
    public enum pokerHandRank {
        STRAIGHT_FLUSH, FOUR_OF_A_KIND, FULL_HOUSE, FLUSH, STRAIGHT, THREE_OF_A_KIND, TWO_PAIR, ONE_PAIR, HIGH_CARD
    }

    /**
     * @param hand The array of cards which represent the player's hand of cards
     * @return a string which represents the hand of cards according to those which is possible in poker games
     */
    public String evaluateToString(ArrayList<Card> hand) {
        try {
            pokerHandRank rank;
            rank = evaluate(hand);
            switch (rank) {
                case STRAIGHT_FLUSH:
                    return "Straight Flush";
                case FOUR_OF_A_KIND:
                    return "Four of a Kind";
                case FULL_HOUSE:
                    return "Full House";
                case FLUSH:
                    return "Flush";
                case STRAIGHT:
                    return "Straight";
                case THREE_OF_A_KIND:
                    return "Three of a Kind";
                case TWO_PAIR:
                    return "Two Pair";
                case ONE_PAIR:
                    return "One Pair";
                case HIGH_CARD:
                    return "High Card";
                default:
                    return "No Clue";
            }
        } catch (NotFiveCardHandException e) {
            return "Not a Five Card Hand";
        }
    }

    /**
     * Uses this class's list of possible poker hands enum to determine an evaluation
     * @param hand The array of cards which represent the player's hand of cards
     * @return one of the possible hand evaluations
     * @throws NotFiveCardHandException if the hand of cards does not have five cards
     */
    public pokerHandRank evaluate(ArrayList<Card> hand) throws NotFiveCardHandException {
        // Pre-process Cards: make sure it is a 5 card hand
        if (hand.size() != 5) {
            throw new NotFiveCardHandException();
        }

        // Analyse Cards
        Boolean allSameSuit = allSameSuit(hand);
        Boolean allInOrder = allInOrder(hand);
        Integer maxNumSameValue = maxNumSameValue(hand);
        Integer numPairs = countPairs(hand);


        // Straight Flush: all same suit: all in order
        if (allSameSuit && allInOrder) return pokerHandRank.STRAIGHT_FLUSH;

        // Four of a Kind: four cards have same value
        if (maxNumSameValue == 4) return pokerHandRank.FOUR_OF_A_KIND;

        // Full House: three cards have same value AND two cards have same value
        if (maxNumSameValue == 3 && numPairs > 0) return pokerHandRank.FULL_HOUSE;

        // Flush: all same suit
        if (allSameSuit) return pokerHandRank.FLUSH;

        // Straight: all in order
        if (allInOrder) return pokerHandRank.STRAIGHT;

        // Three of a Kind: three have same rank
        if (maxNumSameValue == 3) return pokerHandRank.THREE_OF_A_KIND;

        // Two Pair: two have same value AND two have same value
        if (numPairs == 2) return pokerHandRank.TWO_PAIR;

        // One Pair: two have same value
        if (numPairs == 1) return pokerHandRank.ONE_PAIR;

        // High Card: no sequence, no pairs
        return pokerHandRank.HIGH_CARD;
    }


    /**
     * Determines if all the cards in the hand is of the same suit
     * @param fiveCardHand An array of 5 cards which represent a player's hand of cards
     * @return a Boolean indicating whether or not all the cards are of the same suit
     */
    private Boolean allSameSuit(ArrayList<Card> fiveCardHand) {
        Boolean retBool = true;
        for (int i = 0; i < 4 && retBool; i++) {
            retBool = retBool && (fiveCardHand.get(i).getSuit() == fiveCardHand.get(i + 1).getSuit());
        }
        return retBool;
    }

    /**
     * Determines of all the cards are in consecutive order ("K Q J 10 11", "6 5 4 3 2", "A K Q J 10", etc.)
     * @param fiveCardHand An array of 5 cards which represent a player's hand of cards
     * @return
     */
    private Boolean allInOrder(ArrayList<Card> fiveCardHand) {
        // Sort Values
        ArrayList<Integer> sortedValues = new ArrayList<>(Collections.nCopies(5, 0));
        for (int i = 0; i < 5; i++) {
            sortedValues.set(i, fiveCardHand.get(i).getNumber());
        }
        Collections.sort(sortedValues);

        // Check Order
        Boolean retBool = true;
        for (int i = 0; i < 4 && retBool; i++) {
            retBool = retBool && (sortedValues.get(i) == (sortedValues.get(i + 1) - 1));
        }
        // Check Special Case: A K Q J 10
        if (sortedValues.get(0) == 1 && sortedValues.get(1) == 10 && sortedValues.get(2) == 11
                && sortedValues.get(3) == 12 && sortedValues.get(4) == 13) {
            retBool = true;
        }
        return retBool;
    }

    /**
     * Determines how many pairs of cards with the same rank there are in a hand of cards
     * @param fiveCardHand An array of 5 cards which represent a player's hand of cards
     * @return
     */
    private Integer countPairs(ArrayList<Card> fiveCardHand) {
        Integer numPairs;

        // Count how many are the same
        ArrayList<Integer> numSameValues = countSame(fiveCardHand);
        numPairs = 0;
        for (int i = 0; i < numSameValues.size(); i++) {
            if (numSameValues.get(i) == 2)
                numPairs++;
        }

        // Count how many 2's
        return numPairs;
    }

    /**
     * Determines which card rank appears the most and finds how many times that card appears
     * @param fiveCardHand An array of 5 cards which represent a player's hand of cards
     * @return The number of times the most frequent card appears
     */
    private Integer maxNumSameValue(ArrayList<Card> fiveCardHand) {
        ArrayList<Integer> runningCount = countSame(fiveCardHand);
        if (runningCount.isEmpty()) {

            return 0;
        } else {
            return Collections.max(runningCount);
        }
    }

    /**
     * Determines a count of how many times each card in the hand app ears
     * @param fiveCardHand An array of 5 cards which represent a player's hand of cards
     * @return An array with the counts of number of occurrences per in respective places in the array
     */
    private ArrayList<Integer> countSame(ArrayList<Card> fiveCardHand) {
        ArrayList<Integer> runningCount = new ArrayList<>(Collections.nCopies(fiveCardHand.size(), 1));
        ArrayList<Integer> processedNumbers = new ArrayList<>();
        Integer curNum;

        for (int i = 0; i < 5; i++) {
            curNum = fiveCardHand.get(i).getNumber();
            if (processedNumbers.contains(curNum)) {
                runningCount.set(processedNumbers.indexOf(curNum), runningCount.get(processedNumbers.indexOf(curNum)) + 1);
            } else {
                processedNumbers.add(curNum);
            }
        }
        return runningCount;
    }
}
