package games.evaluators.exception;

public class NotFiveCardHandException extends Throwable {
}
