package games.evaluators;

import cards.Card;

import java.util.ArrayList;

/**
 * An abstract class which lets you evaluate a player's hand of cards (to "Two Pairs" or "Straight Flush", for example)
 */
public abstract class HandEvaluator {
    /**
     * @param hand The array of cards which represent the player's hand of cards
     * @return a string which represents the cards as a whole
     */
    abstract public String evaluateToString(ArrayList<Card> hand);
}
