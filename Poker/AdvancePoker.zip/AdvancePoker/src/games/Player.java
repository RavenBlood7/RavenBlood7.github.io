package games;

import cards.Card;

import java.util.ArrayList;

/**
 * A single player within a game which has a "hand" of cards
 */
public class Player {
    /**
     * Array of cards which belong to an individual player
     */
    private ArrayList<Card> handOfCards = new ArrayList<>();

    /**
     * Put a new card in the player's hand of cards
     * @param newCard The card to place in hand
     */
    public void takeCard(Card newCard) {
        handOfCards.add(newCard);
    }


    /**
     * @return a string of all the cards in a player's hand of the form: 1S 3H KS 10D ...
     */
    public String handToString() {
        if (handOfCards.isEmpty()) return "Empty Hand";
        StringBuilder retString = new StringBuilder(handOfCards.get(0).toString());
        for (int i = 1; i < handOfCards.size(); i++) {
            retString.append(" ").append(handOfCards.get(i).toString());
        }
        return retString.toString();
    }

    /**
     * Uses special terminal characters to display the hand of cards to the console
     * @return @return a string of all the cards in a player's hand of the form: 1<S> 3<H> K<S> 10<D> ...
     */
    public String handToStringSpecial() {
        StringBuilder retString = new StringBuilder(handOfCards.get(0).toStringSpecial());
        for (int i = 1; i < handOfCards.size(); i++) {
            retString.append(" ").append(handOfCards.get(i).toStringSpecial());
        }
        return retString.toString();
    }

    public ArrayList<Card> getHand() {
        return handOfCards;
    }
}
