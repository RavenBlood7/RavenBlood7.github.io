package games;

import cards.DeckOfCards;
import cards.exceptions.EmptyDeckException;

import java.util.ArrayList;

/**
 * An abstract class which serves as an basic representation for a single card game
 */
public abstract class CardGameController {

    /**
     * The list of players including the user
     */
    ArrayList<Player> players = new ArrayList<>();
    /**
     * The deck of 52 standard French playing cards
     */
    protected DeckOfCards deckOfCards = new DeckOfCards();
    protected Integer numPlayers;

    /**
     * Constructor which shuffles the deck and creates the players
     * @param numPlayers
     */
    CardGameController(Integer numPlayers){
        // Initialize Players
        this.numPlayers = numPlayers;
        for (int i = 0; i < numPlayers; i++) {
            Player newPlayer = new Player();
            players.add(newPlayer);
        }
    }

    /**
     * Mix cards in deck. Can be extended to provide custom shuffling functionality
     */
    public void shuffleDeck()
    {
        deckOfCards.shuffleDeck();
    }

    /**
     * Deal numCardsPerHand number of cards to each player
     * @param numCardsPerHand
     */
    public void dealCards(Integer numCardsPerHand){
        try {
            for (int i = 0; i < players.size(); i++) {
                for (int j = 0; j < numCardsPerHand; j++) {
                    players.get(i).takeCard(deckOfCards.drawCard());
                }
            }
        }
        catch (EmptyDeckException e)
        {
            e.printStackTrace();
        }
    }

    public Integer getNumPlayers() {
        return numPlayers;
    }

    public Player getPlayer(int index) {
            return players.get(index);
    }

    /**
     * Determine which strength the hand of cards has according to the specific game played
     * @param playerIndex
     * @return a string representing the strength of the hand of cards
     */
    public abstract String evaluatePlayerHand(int playerIndex);
}
