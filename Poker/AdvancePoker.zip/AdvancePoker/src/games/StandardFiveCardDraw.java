package games;

public class StandardFiveCardDraw {
}
