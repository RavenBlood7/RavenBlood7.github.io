package games;

import games.evaluators.HandEvaluator;
import games.evaluators.PokerHandEvaluator;

/**
 * Poker Five Card Draw Game without swapping of cards
 */
public class CustomFiveCardDraw extends CardGameController{
    /**
     * Evaluates 5 card hands into one of 9 poker strengths. (Straight Flush, Four of a Kind, etc)
     */
    private HandEvaluator handEvaluator = new PokerHandEvaluator();

    public CustomFiveCardDraw(Integer numPlayers) {
        super(numPlayers);
    }

    public String evaluatePlayerHand(int playerIndex) {
        return handEvaluator.evaluateToString(players.get(playerIndex).getHand());
    }
}
