---------------------------------------------------------------------------------------------


				Five Card Draw Game


---------------------------------------------------------------------------------------------

________________________________________________

Getting Started:
________________________________________________

1) The Java Source code uses ANT to build and run the application. cd into the root directory 
	which has the build.xml file in it and run one of the following commands:

	build/compile project:	ant build
	package into jar file:	ant package
	run jar file:		ant run
	run all tests:		ant test
	clean:			ant clean


2) In case one cannot compile, there is a backup file in 
	/backup_jar/backup_fiveCardDraw.jar, which can be run with:

	java -jar backup_fiveCardDraw.jar

________________________________________________

Documentation
________________________________________________

1) There is a pdf document located in /doc/TechnicalSpec/TechnicalSpec.pdf

2) JavaDocs can be found in /doc/JavaDocs/index.html